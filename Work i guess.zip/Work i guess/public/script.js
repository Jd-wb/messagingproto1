const socket = io();

document.getElementById("send-button").addEventListener("click", function () {
    const messageInput = document.getElementById("message-input");
    const chatBox = document.getElementById("chat-box");

    const message = messageInput.value.trim();
    if (message) {
        // Emit the message to the server
        socket.emit('chat message', message);
        messageInput.value = ""; // Clear input after sending
    }
});

// Listen for incoming messages
socket.on('chat message', function (msg) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.textContent = msg;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
});

// Optional: Allow pressing Enter to send messages
document.getElementById("message-input").addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        document.getElementById("send-button").click();
    }
});
